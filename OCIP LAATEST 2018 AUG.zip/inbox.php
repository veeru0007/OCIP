<?php
error_reporting(0);
session_start();
$userprofileid=$_SESSION['user_id'];
include("connection.php");
if($userprofileid==true)
{
	$query="SELECT * FROM users WHERE id='$userprofileid'";
	$query1="SELECT * FROM reply_table WHERE issue_id=".$_SESSION['branch_id']." AND solution=''";
	$data=mysqli_query($conn,$query1);
	//echo "Welcome".$result['name'];
}
else
{
   header('location:login.php');	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>
	<script src="js/bootstrap.min.js"></script>  
</head>
<body>
 <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;margin-bottom:0px">
        <div class="container">
        	    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        		 <span class="sr-only">ToggleNavigation</span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 </button>
        	<a class="navbar-brand" href="home.php"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
        	<div class="navbar-collapse collapse">
        		  <ul class="nav navbar-nav navbar-right" id="veeru">
        		      <li ><a href="home.php">Home</a></li>
            		  <li ><a href="logout.php">Logout</a></li>
        		   </ul>
        		 </div>
        	</div>
</nav>

<div class="container" style="padding-top:55px">
			<center><h2>Inbox</h2></center>
		<div class="row">
	    	<div class="table-responsive">
        		<table class='table table-bordered'>
        		      <thead>
        			   <tr>
							   <th>Ref.Id</th>
							   <th>Query</th>
							   <th>Date</th>
							   <th>Oper</th>
        			   </tr>
        			  </thead>
                     <tbody>
        			 <?php
        				while($result=mysqli_fetch_assoc($data))
        				{
        					echo "
        					  <tr>
									<td>".$result['fid']."</td>
									<td>".$result['issue']."</td>
									<td>".$result['date']."</td>
								<td><center><a target='_parent' href='reply.php?sno=$result[s_no]&fid=$result[fid]&iss=$result[issue]' class='btn btn-primary'>Reply</a></center></td>
        						<!--<td><a href='adminremarksdelete.php?rn=$result[id]'onClick='return checkdelete()'class='btn btn-danger'>Del</a></td>-->
        						</tr>
        					";
        				}
        			
        			?> 
            		</tbody>
            	</table>
        	</div>
        </div>
</div>

</body>
</html>
<?php
include("connection.php");
$rollno=$_GET['rn'];
$query="DELETE FROM remarks WHERE s_no=$rollno";
$data=mysqli_query($conn,$query);
if($data)
{
	echo "<script>alert('Record Deleted')</script>";
	?>
	<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=https://ocip.000webhostapp.com/remarks.php">
	<?php
}
else
{
	echo "<font color='red'>Record Not Deleted.";
}

?>
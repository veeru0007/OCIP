<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- CDN  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	-->   
  </head>
 <body>
	<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;">
		<div class="container">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					 <span class="sr-only">ToggleNavigation</span>
					 <span class="icon-bar"></span>
					 <span class="icon-bar"></span>
					 <span class="icon-bar"></span>
				 </button>
			<a class="navbar-brand" href="index.html"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
				<div class="navbar-collapse collapse">
					<ul class="nav navbar-nav navbar-right" id="veeru">
					<li><a href="index.html">Home</a></li>
					<li ><a href="login.php">Login</a></li>
					<li ><a href="AdminLogin.php">Admin</a></li>
					<li ><a href="aboutus.html">About Us</a></li>
				   </ul>
				 </div>
		</div>
	</nav>
		<div class="container-fluid"style="background-color:#4B515D;padding-top:55px">
			  <div class="row">
					<div class="col-md-3">
					</div>
					<div class="col-md-6"style="background-color:#4B515D;">	
								   <center>	
								  <img src="images/images.jpg" class="img-circle" alt="Cinque Terre" width="50%" height="50%">
								   </a> </center>
					</div>
					<div class="col-md-3">
					</div>
				</div>
		</div>
	<div class="container">
		<div class="col-md-3">
		</div>	        
			
			<form action="" method="post" name= login class="col-md-6">
				<div class="form">
					<center><h3>Log In</h3></center>
					<div class="form-group"> 
						<label>UserId :</label>
						<input type="text" name="userid" class="form-control" placeholder="Id" required />
					</div>
					<div class="form-group">
						  <label>Password :</label>
						  <input type="password"  name="password" class="form-control" placeholder="Password" required />      
					</div>
					 <div class="form-group">
						<label>
							<input type="checkbox" value="remember-me"> Remember me
						</label>									
						<center><input type="submit" name="submit"  value="Login" class="btn btn-info"/>&nbsp;&nbsp;&nbsp;&nbsp;
						<a href="AdminLogin.php" class="btn btn-info" role="button">Admin</a><br><br></center>
					</div>  
				</div>	
			</form>
			
			
		<div class="col-md-3">
		</div>	
	</div>
	
	<div class="container">
  <div class="col-md-3">
  </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<!-- CDN
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	-->
</body>
</html>
<?php
if(isset($_POST['submit']))
{
	$id=$_POST['userid'];
	$pwd=$_POST['password'];
	$query="SELECT * FROM users WHERE id='$id' && password='$pwd'";
	$data=mysqli_query($conn,$query);
	$total=mysqli_num_rows($data);
	if($total==1)
	{
		$_SESSION['user_id']=$id;
		header('location:home.php');
	}
	else
	{
		echo "<marquee><font color='#ff6600'>Login Failed. Try Again.</marquee>";
	}
}
?>
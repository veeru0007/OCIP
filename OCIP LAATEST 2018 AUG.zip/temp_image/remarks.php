<?php
	session_start();
	$userprofileid=$_SESSION['user_id'];
	include("connection.php");
	error_reporting(0);
	if($userprofileid==true)
    {
		$query="SELECT *FROM remarks WHERE id='$userprofileid'";
			$data=mysqli_query($conn,$query);
			$rows=mysqli_num_rows($data);
	}
	else
	{
	   header('location:login.php');	
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- CDN  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	-->  
	<script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>
  <style type="text/css">
		.bs-example{
			margin: 20px;
		}
	</style>
  
  </head>
<body>
 <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;margin-bottom:0px">
        <div class="container">
        	    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        		 <span class="sr-only">ToggleNavigation</span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 </button>
        	<a class="navbar-brand" href="home.php"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
        	<div class="navbar-collapse collapse">
        		  <ul class="nav navbar-nav navbar-right" id="veeru">
        		      <li ><a href="home.php">Home</a></li>
            		  <li ><a href="logout.php">Logout</a></li>
        		   </ul>
        		 </div>
        	</div>
</nav>
<div class="container" style="padding-top:55px">
  <div class="row">
		<div class="col-xs-3">
			</div>
		<div class="col-md-6" >	
		 <h2>Remarks</h2>
			<form method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label>Id</label>
					<input type="text" name="id" value="<?php echo $userprofileid;?>" class="form-control" readonly>
				 </div>
				 <div class="form-group">
					<label>Hostel:</label>
					<input type="text" class="form-control" name="hostel" placeholder="Hostel" />
				   </div>
				   <div class="form-group">
					   <label>Academic:</label>
					   <input type="text" class="form-control" name="academic" placeholder="Academic" />
				   </div>
			   
				   <div class="form-group">
					<label>Placement:</label>
					<input type="text" class="form-control"name="placement" placeholder="Placement" />
					</div>

				
					<div class="form-group">
					<label>Examination:</label>
					<input type="text" class="form-control"name="examination" placeholder="Exam's" />
					</div>
				
					<div class="form-group">
					   <label>DutyLeaves:</label>
					   <input type="text" class="form-control" name="dutyleave" placeholder="dl's" />
				   </div>
				   <!--
				 <div class="form-group">
					<label>ScreenShot</label>
					<input type="file" name="uploadfile" class="form-control">
				 </div>-->
				 <div class="form-group">	       
					 <input type="submit" name="submit" class="btn btn-info">
				 </div>
			</form>
		</div>
	</div>
		<?php
			
			
			if($rows!=0)
			{
		?>
		<div class="row">
			<div class="bs-example">
				<div class="table-responsive">
					<table class='table table-bordered'>
						  <thead>
						   <tr>
							   <!--<th>S_No</th>-->
							   <th><center>Date<center></th>
							   <th>Hostel</th>
							   <th>Academic</th>
							   <th>Placement</th>
							   <!--<th>Operations</th>-->
						   </tr>
						  </thead>
						 <tbody>
						 <?php
							while($result=mysqli_fetch_assoc($data))
							{
								echo "
								  <tr>
									<!--<td>".$result['s_no']."</td>-->
									<td>".$result['date']."</td>
									<td>".$result['hostel']."</td>
									<td>".$result['academic']."</td>
									<td>".$result['placement']."</td>
									<!--<td><a href='remarksdelete.php?rn=$result[s_no]'onClick='return checkdelete()'class='btn btn-danger'>Del</a></td>-->
									</tr>
								";
							}
			}
						?> 
					</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php
			
			
			if($rows!=0)
			{
		?>
		<div class="row">
				
			<div class="col-xs-12">
				<h2>Forwarded Queries</h2>
			</div>
			
		</div>
		<div class="row">
			<div class="bs-example">
				<div class="table-responsive">
					<table class='table table-bordered'>
						  <thead>
						   <tr>
							   <th><center>Date<center></th>
							   <th>Hostel</th>
							   <th>Academic</th>
							   <th>Placement</th>
							   <!--<th>Operations</th>-->
						   </tr>
						  </thead>
						 <tbody>
						 <?php
							while($result=mysqli_fetch_assoc($data))
							{
							}
			}
						?> 
					</tbody>
					<table>
				</div>
			</div>
		</div>
		

</div>
	<script>
		function checkdelete()
		{
			return confirm('Are U sure u want to delete??');
		}
</script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php    
   if( isset($_POST['submit'])  ){
	   
	   $filename=$_FILES["uploadfile"]["name"];
	   $tempname=$_FILES["uploadfile"]["temp_name"];
	   $folder="student/".$filename;
	   move_uploaded_file($tempname,$folder);
	   
	   
	   $id=mysqli_real_escape_string($conn,strip_tags($_POST['id']));
	   $hostel=mysqli_real_escape_string($conn,strip_tags($_POST['hostel']));
	   $academic=mysqli_real_escape_string($conn,strip_tags($_POST['academic']));
	   $placement=mysqli_real_escape_string($conn,strip_tags($_POST['placement']));
	   $examination=mysqli_real_escape_string($conn,strip_tags($_POST['examination']));
	   $dutyleave=mysqli_real_escape_string($conn,strip_tags($_POST['dutyleave']));
	   $trn_date = date("Y-m-d H:i:s");
	   $ins_sql="INSERT INTO remarks (id,hostel,academic,placement,examination,dutyleaves,picsource,date) VALUES('$id','$hostel','$academic','$placement','$examination','$dutyleave','$folder','$trn_date')";
	   $data=mysqli_query($conn,$ins_sql);
	   if($data){  ?>
		     <script>window.location="remarks.php"</script>   
	   <?php
		echo "<marquee><font color='green'>Record Submitted Successfully.</marquee>";	   
		}
		else
		{
			echo "<marquee><font color='#ff6600'>Record Not Submitted.</marquee>";
			}
}
else
{
	
}

?>
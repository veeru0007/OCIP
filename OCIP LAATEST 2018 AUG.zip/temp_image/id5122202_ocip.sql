-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 26, 2018 at 12:47 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id5122202_ocip`
--

-- --------------------------------------------------------

--
-- Table structure for table `ausers`
--

CREATE TABLE `ausers` (
  `id` int(5) NOT NULL,
  `name` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `branch` text NOT NULL,
  `designation` text NOT NULL,
  `picsource` varchar(500) NOT NULL,
  `contact` text NOT NULL,
  `location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ausers`
--

INSERT INTO `ausers` (`id`, `name`, `password`, `email`, `branch`, `designation`, `picsource`, `contact`, `location`) VALUES
(25950, 'Veerendra', '1234567890', 'chveerendra0007@gmail.com', 'CSE', 'student', 'student/veeruu.jpg', '9959495245', 'JALANDHAR');

-- --------------------------------------------------------

--
-- Table structure for table `remarks`
--

CREATE TABLE `remarks` (
  `s_no` int(11) NOT NULL,
  `id` int(5) NOT NULL,
  `hostel` text NOT NULL,
  `academic` text NOT NULL,
  `placement` text NOT NULL,
  `examination` text NOT NULL,
  `dutyleaves` text NOT NULL,
  `picsource` varchar(500) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remarks`
--

INSERT INTO `remarks` (`s_no`, `id`, `hostel`, `academic`, `placement`, `examination`, `dutyleaves`, `picsource`, `date`) VALUES
(9, 25950, 'Fhghhjj', '', '', '', '', 'student/', '2018-04-21 10:56:37'),
(10, 26180, 'jhjk', 'kjdjkbsdk', 'jkjbjksdkj', 'dfjkgjksd', 'kjbkjbf', 'student/', '2018-04-21 11:17:31'),
(11, 26180, '2gkjhshgjsh', 'jnbnkdnjk', 'kjbsjknghn', 'nbknkjsnkjfngk', 'kbkjskjbnk', 'student/', '2018-04-21 11:18:03'),
(12, 71700, 'fan issue', '', 'company de register', '', '', 'student/', '2018-04-21 11:18:51'),
(13, 25950, 'Gdhdhdvdbs', 'Dhdhdhdhhd', '', '', '', 'student/', '2018-04-21 11:47:27'),
(14, 25950, 'Gdhdbxbxbxbx', '', 'Hdhdjdjid', '', '', 'student/', '2018-04-21 12:14:15'),
(15, 25950, 'Yehdhdheiie', '', '', 'Hdhdhdjdjdjd', '', 'student/', '2018-04-21 12:27:44'),
(16, 25950, 'BVHCHCBV', 'GFHDGDHGJDFH', 'DJFH', '', '', 'student/', '2018-04-23 16:45:11'),
(17, 71700, 'Hostel fee', '', '', '', '', 'student/', '2018-04-23 17:49:03'),
(18, 71700, 'Hlo', '', '', '', '', 'student/', '2018-04-23 22:20:47');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `s_no` int(11) NOT NULL,
  `id` int(5) NOT NULL,
  `hostelinfo` text COLLATE utf8_unicode_ci NOT NULL,
  `academicinfo` text COLLATE utf8_unicode_ci NOT NULL,
  `placementinfo` text COLLATE utf8_unicode_ci NOT NULL,
  `examinationinfo` text COLLATE utf8_unicode_ci NOT NULL,
  `dutyleavesinfo` text COLLATE utf8_unicode_ci NOT NULL,
  `hostel` datetime NOT NULL,
  `academic` datetime NOT NULL,
  `placement` datetime NOT NULL,
  `examination` datetime NOT NULL,
  `dutyleaves` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`s_no`, `id`, `hostelinfo`, `academicinfo`, `placementinfo`, `examinationinfo`, `dutyleavesinfo`, `hostel`, `academic`, `placement`, `examination`, `dutyleaves`) VALUES
(3, 26180, 'jjhjkhk', 'jkjhhk', '', '', '', '2018-04-22 12:30:00', '2018-04-23 15:30:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 25950, 'jdfkjgjdkf', '', '', '', '', '2018-04-04 13:30:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 71700, 'replace with new fan', '', 'it will  be done ', '', '', '2018-04-23 10:30:00', '0000-00-00 00:00:00', '2018-04-26 16:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 25950, 'Hdhdhdjd', '', '', '', '', '2018-04-23 15:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 25950, 'Hshdhdu', '', '', '', '', '2018-05-22 09:12:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 25950, 'Hdhdhdjd', '', '', '', '', '2018-05-22 10:34:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 71700, 'New one', '', '', '', '', '2018-05-24 10:25:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 71700, 'JFGHFHJ', '', '', '', '', '2018-04-03 05:02:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 71700, 'You are final year ', '', '', '', '', '2018-04-24 17:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `name` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `branch` text NOT NULL,
  `designation` text NOT NULL,
  `picsource` varchar(500) NOT NULL,
  `contact` text NOT NULL,
  `location` text NOT NULL,
  `joindate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `branch`, `designation`, `picsource`, `contact`, `location`, `joindate`) VALUES
(25950, 'Veerendra', '123456789', 'chveerendra0007@gmail.com', 'CSE', 'STUDENT', 'student/veeruu.jpg', '9959495245', 'JALANDHAR', '0000-00-00 00:00:00'),
(26180, 'Himanshu', 'Jd@007', 'himanshu.tiwari.me@gmail.com', 'CSE', 'STUDENT', 'student/himanshu.jpg', '8755043788', 'JALANDHAR', '0000-00-00 00:00:00'),
(64570, 'Chandravardhan', 'Chandu@123', 'chandravardhanreddym.1996@gmail.com', 'CSE', 'STUDENT', 'student/chandu.jpg', '7307450767', 'NOIDA', '0000-00-00 00:00:00'),
(71700, 'Hitesh', 'Comedy@111', 'hk60084@gmail.com', 'CSE', 'STUDENT', 'student/', '8297192877', 'JALANDHAR', '2018-04-23 12:35:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ausers`
--
ALTER TABLE `ausers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remarks`
--
ALTER TABLE `remarks`
  ADD UNIQUE KEY `s_no` (`s_no`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `remarks`
--
ALTER TABLE `remarks`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `remarks`
--
ALTER TABLE `remarks`
  ADD CONSTRAINT `remarks_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

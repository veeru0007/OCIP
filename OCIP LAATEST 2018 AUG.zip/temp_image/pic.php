<?php
error_reporting(0);
?>
<html>
    <body>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="uploadfile" value=""/>
            <input type="submit" name="submit" value="Upload File" />
            </form>
    </body>
</html>
<?php
//print_r($_FILES["uploadfile"]);
$filename=$_FILES["uploadfile"]["name"];
$tempname=$_FILES["uploadfile"]["tmp_name"];
$folder="temp_image/".$filename;
echo $folder;
move_uploaded_file($tempname,$folder);
?>
<?php
   session_start();
	$userprofileid=$_SESSION['user_id'];
	include("connection.php");
		error_reporting(0);
	if($userprofileid==true)
    {
		
	}
	else
	{
	   header('location:login.php');	
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- CDN  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	-->   
  </head>
<body>
 <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;margin-bottom:0px">
	<div class="container">
	    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		 <span class="sr-only">ToggleNavigation</span>
		 <span class="icon-bar"></span>
		 <span class="icon-bar"></span>
		 <span class="icon-bar"></span>
		 </button>
	<a class="navbar-brand" href="admin.php"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
	<div class="navbar-collapse collapse">
		  <ul class="nav navbar-nav navbar-right" id="veeru">
		      <li ><a href="admin.php">Home</a></li>
		      <li ><a href="allusers.php">Users</a></li>
    		  <li ><a href="logout.php">Logout</a></li>
		   </ul>
		 </div>
	</div>
</nav>
<div class="container" style="padding-top:55px">
		<div class="row">
                  <div class="col-md-3">
                  </div>
               <div class="col-md-6" >	
            		 <h2>Remarks</h2>
                    <form method="get" enctype="multipart/form-data">
            			<div class="form-group">
            	            <label>Id</label>
            		        <input type="text" name="id" value="<?php echo $_GET['id'];?>" class="form-control" readonly>
            	         </div>
            			 <div class="form-group">
            				<label>Hostel:</label>
            				<input type="text" class="form-control" name="hostel" value="<?php echo $_GET['hs'];?>"  readonly />
							<input type="text" class="form-control" name="hid" placeholder="Faculty Id" />
							<input type="text" class="form-control" name="hsi" placeholder="Hostel solution" />
							<input type="text" class="form-control" name="hsr" placeholder="Room No" />
							<input type="datetime-local" class="form-control" name="hsd"  />
            			   </div>
            			   <div class="form-group">
            				   <label>Academic:</label>
            				   <input type="text" class="form-control" name="academic" value="<?php echo $_GET['acd'];?>"  readonly />
							   <input type="text" class="form-control" name="aid" placeholder="Faculty Id"  />
								<input type="text" class="form-control" name="acdi" placeholder="Academic solution"  />
								<input type="text" class="form-control" name="acdr" placeholder="Room No" />
							   <input type="datetime-local" class="form-control" name="acdd" />
            			   </div>
            		   
            			   <div class="form-group">
            				<label>Placement:</label>
            				<input type="text" class="form-control"name="placement" value="<?php echo $_GET['plc'];?>"  readonly />
							<input type="text" class="form-control"name="pid" placeholder="Faculty Id"  />
							<input type="text" class="form-control"name="plci" placeholder="Placement solution"  />
							<input type="text" class="form-control" name="plcr" placeholder="Room No" />
							<input type="datetime-local" class="form-control"name="plcd"   />
            				</div>
            
            			
            				<div class="form-group">
            				<label>Examination:</label>
            				<input type="text" class="form-control"name="examination" value="<?php echo $_GET['exm'];?>"  readonly />
							<input type="text" class="form-control"name="eid" placeholder="Faculty Id"  />
							<input type="text" class="form-control"name="exmi" placeholder="Exam's solution"  />
							<input type="text" class="form-control" name="exmr" placeholder="Room No" />
							<input type="datetime-local" class="form-control"name="exmd"  />
            				</div>
            			
            				<div class="form-group">
            				   <label>DutyLeaves:</label>
            				   <input type="text" class="form-control" name="dutyleave" value="<?php echo $_GET['dl'];?>"  readonly />
							   <input type="text" class="form-control" name="did" placeholder="Faculty Id"  />
							   <input type="text" class="form-control" name="dli" placeholder="dl's solution"  />
							   <input type="text" class="form-control" name="dlr" placeholder="Room No" />
							   <input type="datetime-local" class="form-control" name="dld" />
            			   </div>
            			 <!--<div class="form-group">
            	            <label>ScreenShot</label>
            		        <input type="file" name="uploadfile" class="form-control">
            	         </div>-->
            	         <div class="form-group">	       
            		         <input type="submit" name="submit" class="btn btn-info">
            	         </div>
            		</form>
                </div>
            </div>    




</div>
</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php
error_reporting(0);	
if( isset($_GET['submit'])  ){
	   
  
	   $id=$_GET['id'];
	   $hsi=$_GET['hsi'];
	   $acdi=$_GET['acdi'];
	   $plci=$_GET['plci'];
	   $exmi=$_GET['exmi'];
	   $dli=$_GET['dli'];
	   $hid=$_GET['hid'];
	   $aid=$_GET['aid'];
	   $pid=$_GET['pid'];
	   $eid=$_GET['eid'];
	   $did=$_GET['did'];
	   $hsd=$_GET['hsd'];
	   $acdd=$_GET['acdd'];
	   $plcd=$_GET['plcd'];
	   $exmd=$_GET['exmd'];
	   $dld=$_GET['dld'];
	   $hsr=$_GET['hsr'];
	   $acdr=$_GET['acdr'];
	   $plcr=$_GET['plcr'];
	   $exmr=$_GET['exmr'];
	   $dlr=$_GET['dlr'];
	   $ins_sql="INSERT INTO schedule(id,hostelinfo,academicinfo,placementinfo,examinationinfo,dutyleavesinfo,hostel,
	   academic,placement,examination,dutyleaves,hid,aid,pid,eid,did,hostelroom,academicroom,placementroom,examinationroom,dutyleavesroom) 
	   VALUES('$id','$hsi','$acdi','$plci','$exmi','$dli','$hsd','$acdd','$plcd','$exmd','$dld','$hid','$aid','$pid','$eid','$did','$hsr','$acdr','$plcr','$exmr','$dlr');";
	   $data=mysqli_query($conn,$ins_sql);
	  /* if($data){  ?>
		     <script>window.location="profile.php"</script>   
	   <?php }*/
	if($data)
	{
		echo "<marquee><font color='green'>Record Submitted.</marquee>";
	}
	else{
		echo "<marquee><font color='#ff6600'>data not inserted Record Not Submitted.</marquee>";
		}
}
else
{
	//echo "<font color='blue'>Press the Button for update";
}
?>
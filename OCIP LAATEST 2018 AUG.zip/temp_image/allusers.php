<?php
   session_start();
	$userprofileid=$_SESSION['user_id'];
	include("connection.php");
		error_reporting(0);
	if($userprofileid==true)
    {
		$query="SELECT *FROM users";
		$data=mysqli_query($conn,$query);
		$rows=mysqli_num_rows($data);
	}
	else
	{
	   header('location:login.php');	
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- CDN  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	-->   
  </head>
<body>
 <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;margin-bottom:0px">
	<div class="container">
	    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		 <span class="sr-only">ToggleNavigation</span>
		 <span class="icon-bar"></span>
		 <span class="icon-bar"></span>
		 <span class="icon-bar"></span>
		 </button>
	<a class="navbar-brand" href="admin.php"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
	<div class="navbar-collapse collapse">
		  <ul class="nav navbar-nav navbar-right" id="veeru">
		      <li ><a href="admin.php">Home</a></li>
		      <li ><a href="allusers.php">Users</a></li>
    		  <li ><a href="logout.php">Logout</a></li>
		   </ul>
		 </div>
	</div>
</nav>
<div class="container" style="padding-top:55px">
		<div class="row">
			  <div class="col-md-3">
			  </div>
			<div class="col-md-6" >	
				<h2>Insert new User</h2>
				<form method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label>Id</label>
						<input type="text" name="id" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Name</label>
						<input type="text" name="name" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Password</label>
						<input type="password" name="password" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Email</label>
						<input type="email"name="email" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Branch</label>
						<input type="text" name="branch" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Designation</label>
						<input type="text" name="designation" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Image</label>
						<input type="file" name="uploadfile" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Contact Number</label>
						<input type="text" name="contactnumber" class="form-control">
					 </div>
					 <div class="form-group">
						<label>Location</label>
						<input type="text" name="location" class="form-control">
					 </div>
					 <div class="form-group">	       
						 <input type="submit" name="submit_user" class="btn btn-primary">
					 </div>
				</form>
			</div>
		</div>	
			<?php
		if($rows!=0)
		{
			?>
		<div class="row">
		
				<table class='table'>
					  <thead>
					   <tr>
						   <th>ID</th>
						   <th>Name</th>
						   <th>Contact</th>
						   <th>Delete</th>
					   </tr>
					  </thead>
					 <tbody>
					 <?php
						while($result=mysqli_fetch_assoc($data))
						{
							echo "
							  <tr>
								<td>".$result['id']."</td>
								<td>".$result['name']."</td>
								<td>".$result['contact']."</td>
								<td><a href='userdelete.php?rn=$result[id]'onClick='return checkdelete()'class='btn btn-danger'>Del</a></td>
								</tr>
							";
						}
					}
					?> 
				</tbody>
				<table>
		</div>
</div>
	<script>
		function checkdelete()
		{
			return confirm('Are U sure u want to delete??');
		}
</script>
</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php    
   if( isset($_POST['submit_user'])  ){
	   
	   $filename=$_FILES["uploadfile"]["name"];
	   $tempname=$_FILES["uploadfile"]["temp_name"];
	   $folder="student/".$filename;
	   move_uploaded_file($tempname,$folder);
	   
	   
	   $id=mysqli_real_escape_string($conn,strip_tags($_POST['id']));
	   $user=mysqli_real_escape_string($conn,strip_tags($_POST['name']));
	   $password=mysqli_real_escape_string($conn,strip_tags($_POST['password']));
	   $email=mysqli_real_escape_string($conn,strip_tags($_POST['email']));
	   $branch=mysqli_real_escape_string($conn,strip_tags($_POST['branch']));
	   $designation=mysqli_real_escape_string($conn,strip_tags($_POST['designation']));
	   $location=mysqli_real_escape_string($conn,strip_tags($_POST['location']));
	   $join_date = date("Y-m-d H:i:s");
	   if( isset($_POST['contactnumber']) )
	   {
	        $contactnumber=mysqli_real_escape_string($conn,strip_tags($_POST['contactnumber']));  
	      }
	   $ins_sql="INSERT INTO users (id,name,password,email,branch,designation,picsource,contact,location,joindate) VALUES('$id','$user','$password','$email','$branch','$designation','$folder','$contactnumber','$location','$join_date')";
	   if(mysqli_query($conn,$ins_sql)){  ?>
		     <script>window.location="allusers.php"</script>   
	   <?php }
   }

?>
<?php
	session_start();
	$userprofileid=$_SESSION['user_id'];
	include("connection.php");
	error_reporting(0);
	if($userprofileid==true)
    {
		$query="SELECT hostel,hostelroom FROM schedule hid='$userprofileid'";
			$data=mysqli_query($conn,$query);
			$rows=mysqli_num_rows($data);
	}
	else
	{
	   header('location:login.php');	
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- CDN  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	-->  
	<script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>
  </head>
<body>
<div class="container-fluid">
	<?php
			if($rows!=0)
			{
				?>
		<div class="row">
	    	<div class="table-responsive">
        		<table class='table table-bordered'>
        		      <thead>
        			   <tr>
						   <th>No</th>
        			       <th>Hostel</th>
        			   </tr>
        			  </thead>
                     <tbody>
        			 <?php
        				$c=1;
						while($result=mysqli_fetch_assoc($data))
        				{
        					echo "
							<tr>
								<td rowspan='2'>$c</td>
        						<td>".$result['hostelroom']."</td>
        						</tr>
        					  <tr>";
							  if($result['hostel']!='0000-00-00 00:00:00')
							  {
								echo"<td>".$result['hostel']."</td>"; 
							  }
        						echo"</tr>       				
								";
							$c++;
        				}
						
        			}
        			?> 
            		</tbody>
            	<table>
        	</div>
        </div>


</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>		
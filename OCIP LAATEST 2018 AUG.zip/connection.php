<?php
ob_start();
$timezone = date_default_timezone_set("Asia/Kolkata");
$conn=mysqli_connect("localhost","id5122202_ocip","Veeru@0007","id5122202_ocip");
if($conn)
{
	echo "";
}
else
{
	die("Connection failed".mysqli_connect_error());
}
?>
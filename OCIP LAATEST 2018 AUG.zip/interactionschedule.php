<?php
session_start();
$userprofileid=$_SESSION['user_id'];
include("connection.php");
error_reporting(0);
if($userprofileid==true)
{
	$query="SELECT * FROM schedule_allotment WHERE id='$userprofileid' and date_allot >= NOW()";
	$data=mysqli_query($conn,$query);
	$rows=mysqli_num_rows($data);
	//echo "Welcome".$result['name'];
}
else
{
   header('location:login.php');	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>
	<script src="js/bootstrap.min.js"></script>  
</head>
<body>
 <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;margin-bottom:0px">
        <div class="container">
        	    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        		 <span class="sr-only">ToggleNavigation</span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 </button>
        	<a class="navbar-brand" href="home.php"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
        	<div class="navbar-collapse collapse">
        		  <ul class="nav navbar-nav navbar-right" id="veeru">
        		      <li ><a href="home.php">Home</a></li>
            		  <li ><a href="logout.php">Logout</a></li>
        		   </ul>
        		 </div>
        	</div>
</nav>
<div class="container" style="padding-top:55px">
   <center><h2>Schedule</h2></center>
   <?php
			if($rows!=0)
			{
				?>	
	<div class="row">
	    	<div class="table-responsive">
        		<table class='table table-bordered'>
        		      <thead>
        			   <tr>
        			       <th>S.No</th>
        				   <th>Date</th>
        				   <th>Room No</th>
        			   </tr>
        			  </thead>
                     <tbody>
        			 <?php
        				$c=1;
						while($result=mysqli_fetch_assoc($data))
        				{
        					echo "
							<tr>
								
        						<td>$c</td>
        						<td>".$result['date_allot']."</td>
        						<td>".$result['room']."</td>
    						</tr>      				
        					";
							$c++;
        				}
						
        			}
        			?> 
            		</tbody>
            	</table>
        	</div>
        </div>
</div>
</body>
</html>

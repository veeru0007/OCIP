<?php
error_reporting(0);
//echo $_POST['rollno'];
session_start();
include("connection.php");
$userprofileid=$_SESSION['user_id'];
if($userprofileid==true)
{
	$query="SELECT * FROM users WHERE id='$userprofileid'";
	$data=mysqli_query($conn,$query);
	$result=mysqli_fetch_assoc($data);
	$rows=mysqli_num_rows($data);
	//echo "Welcome".$result['name'];
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>

	<link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>
	<script src="js/bootstrap.min.js"></script>
  </head>
<body>
 <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;margin-bottom:0px">
        <div class="container">
        	    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        		 <span class="sr-only">ToggleNavigation</span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 <span class="icon-bar"></span>
        		 </button>
        	<a class="navbar-brand" href="home.php"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
        	<div class="navbar-collapse collapse">
        		  <ul class="nav navbar-nav navbar-right" id="veeru">
        		      <li ><a href="home.php">Home</a></li>
            		  <li ><a href="logout.php">Logout</a></li>
        		   </ul>
        		 </div>
        	</div>
</nav>
<div class="container" style="padding-top:55px">
		<div class="row">
			  <div class="col-md-3">
			  </div>
			<div class="col-md-6" >	
				<h2>Update Profile</h2>
				<center>	
		         <a href='<?php echo $result['picsource'];?>'>
				 <img src='<?php echo $result['picsource'];?>' class="img-circle" alt="Cinque Terre" width="50%" height="50%">
				 </a>
			    </center>
				<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Change Image</label>
				<input type="file" name="uploadfile" class="form-control">
			 </div>
			<div class="form-group">	       
				<input type="submit" name="upload" value="upload" class="btn btn-primary">
			</div>
			</form>
				<form method="get" enctype="multipart/form-data">
					<div class="form-group">
						<label>Id</label>
						<input type="text" name="id" class="form-control" value="<?php echo $_GET['id'];?>" readonly>
					 </div>
					 <div class="form-group">
						<label>Name</label>
						<input type="text" name="nm" class="form-control" value="<?php echo $_GET['nm'];?>">
					 </div>
					 <div class="form-group">
						<label>Password</label>
						<input type="text" name="pwd" class="form-control"value="<?php echo $_GET['pwd'];?>">
					 </div>
					 <div class="form-group">
						<label>Confirm Password</label>
						<input type="text" name="cpwd" class="form-control"value="<?php echo $_GET['pwd'];?>">
					 </div>
					 <div class="form-group">
						<label>Email</label>
						<input type="email"name="em" class="form-control"value="<?php echo $_GET['em'];?>">
					 </div>
					 <div class="form-group">
						<label>Branch</label>
						<input type="text" name="br" class="form-control"value="<?php echo $_GET['br'];?>">
					 </div>
					 <div class="form-group">
						<label>Designation</label>
						<input type="text" name="ds" class="form-control"value="<?php echo $_GET['ds'];?>">
					 </div>
					 <div class="form-group">
						<label>Contact Number</label>
						<input type="text" name="cn" class="form-control"value="<?php echo $_GET['cn'];?>">
					 </div>
					 <div class="form-group">
						<label>Location</label>
						<input type="text" name="lc" class="form-control"value="<?php echo $_GET['lc'];?>">
					 </div>
					 <div class="form-group">	       
						 <input type="submit" name="submit" class="btn btn-info">
					 </div>
				</form>
			
			</div>
			<div class="col-md-3">
			  </div>
		</div>
	</div>	
<?php	
$filename=$_FILES["uploadfile"]["name"];
$tempname=$_FILES["uploadfile"]["tmp_name"];
$folder="student/".$filename;
move_uploaded_file($tempname,$folder);
//echo $folder;
if($filename!="")
{
$ins_sql="UPDATE users SET picsource='$folder' WHERE id='$userprofileid'";
$data1=mysqli_query($conn,$ins_sql);
	if($data1==true)
	{
		?>
		     <script>window.location="profile.php"</script>   
	   <?php	
	}
}
if( isset($_GET['submit'])  ){
	   $id=$_GET['id'];
	   $user=$_GET['nm'];
	   $password=$_GET['pwd'];
	   $cpassword=$_GET['cpwd'];	   
	   $email=$_GET['em'];
	   $branch=$_GET['br'];
	   $designation=$_GET['ds'];
	   $location=$_GET['lc'];
	   if( isset($_GET['cn']) )
	   {
	        $contactnumber=$_GET['cn'];  
	      }
		if($password===$cpassword)
		{
		$ins_sql="UPDATE users SET name='$user',password='$password',email='$email',branch='$branch',designation='$designation',contact='$contactnumber',location='$location' WHERE id='$id';";
	    $data2=mysqli_query($conn,$ins_sql);	
		}
	 if($data2){  ?>
		     <script>window.location="profile.php"</script>   
	   <?php }
	else{
		echo "<marquee><font color='#ff6600'>Record Not Updated.Recheck the password.</marquee>";
		}
}
?>

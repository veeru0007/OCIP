<?php
session_start();
$userprofileid=$_SESSION['user_id'];
include("connection.php");
if($userprofileid==true)
{	
	
}
else
{
   header('location:login.php');	
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="icon" href="images/icon.png">
    <title>ONLINE COUNCELLING INTERACTION PORTAL</title>
	<script src="https://use.fontawesome.com/219a53cdc5.js"></script>
	
     <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>
	<script src="js/bootstrap.min.js"></script>
  </head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#4B515D;">
	<div class="container">
	    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		 <span class="sr-only">ToggleNavigation</span>
		 <span class="icon-bar"></span>
		 <span class="icon-bar"></span>
		 <span class="icon-bar"></span>
		 </button>
	<a class="navbar-brand" href="admin.php"><i class="fa fa-male" aria-hidden="true"></i>&nbsp;&nbsp;OCIP</a>
	<div class="navbar-collapse collapse">
		  <ul class="nav navbar-nav navbar-right" id="veeru">
		      <li ><a href="admin.php">Home</a></li>
		      <li ><a href="allusers.php">Users</a></li>
    		  <li ><a href="logout.php">Logout</a></li>
		   </ul>
		 </div>
	</div>
</nav>
<div class="container"style="padding-top:55px">
<center><h3>Schedule Allotment</h3></center>
<div class="row" style="height:50px;">
</div>
	<div class="row">	
		<div class="col-md-4">
		</div>	        
			
			<form action="" method="post" name= schedule_allotment class="col-md-4">
				<div class="form">
					
					<div class="form-group"> 
						<label>UserId :</label>
						<input type="text" name="userid" class="form-control" placeholder="Id" required />
					</div>
					<div class="form-group">
						  <label>Allotment Date</label>
						  <input type="datetime-local"  name="date_allot" class="form-control" required />      
					</div>
					<div class="form-group"> 
						<label>Room :</label>
						<input type="text" name="room" class="form-control" placeholder="Room_No" required />
					</div>
					 <div class="form-group">									
						<center><input type="submit" name="submit"  value="submit" class="btn btn-info"/>
						</center>
					</div>  
				</div>	
			</form>	
			<div class="col-md-4">
			</div>
	</div>
</div>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
$id=$_POST['userid'];
$date_allot=$_POST['date_allot'];
$room=$_POST['room'];
$query="INSERT INTO schedule_allotment (id,date_allot,room) VALUES ('$id','$date_allot','$room')";
$data=mysqli_query($conn,$query);
	if($data)
	{
		echo "<marquee><font color='green'>Record Entered Successfully.</font></marquee>";
	}
	else{
		echo "<marquee><font color='red'>Record Not Entered.</font></marquee>";
	}
}
?>





